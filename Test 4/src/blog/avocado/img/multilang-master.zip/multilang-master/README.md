# ITGID.info
## Делаем мультиязычный сайт на JavaScript
### https://itgid.info

Мульти lang сайт на JavaScript
### Посмотреть видеоурок на Youtube
https://youtu.be/MKx31x5u_SQ
[![Посмотреть видео](https://github.com/itgidinfo/multilang/blob/master/images/cover.png?raw=true)](https://youtu.be/MKx31x5u_SQ)

### Курсы ItGid.info

- JavaScript 2.0 (https://itgid.info/course/javascript-2)
- HTML для будущих JS разработчиков (https://itgid.info/course/html)
- Методы массивов JavaScript (https://itgid.info/course/arraymethod)
- ReactJS (https://itgid.info/course/reactjs)

В каждом курсе вас ждет много практических задач, поддержка, проверка ДЗ, разбор ошибок, помощью в решении
