const langArr = {
    "unit" :  {
        "ru": "создаем многоязычный сайт",
        "en": "build a multi language site ",
        "ua": "створюємо багатомовний сайт",
    }, 
    "chip": {
        "ru": "графический чип",
        "en": "graphics processing unit",
        "ua": "графічний чіп",
    }, 
    "memory": {
        "ru": "объем памяти",
        "en": "memory size",
        "ua": "oбсяг пам'яті",
    }, 
    "memory-type": {
        "ru": "тип памяти",
        "en": "memory type",
        "ua": "nип пам'яті",
    }, 
    "cool": {
        "ru": "тип системы охлаждения",
        "en": "сooling system type",
        "ua": "тип системи охолодження",
    }, 
    "more": {
        "ru": "детально о товаре",
        "en": "more details",
        "ua": "детально про товар",
    }, 
}